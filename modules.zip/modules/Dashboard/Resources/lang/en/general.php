<?php

return [

    'name'              => 'Dashboard',
    'description'       => 'This is my awesome module',

];